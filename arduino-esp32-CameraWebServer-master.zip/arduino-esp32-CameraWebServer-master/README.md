# CameraWebServer Example for ESP32-CAM in Arduino IDE

Project instructions: https://randomnerdtutorials.com/esp32-cam-video-streaming-face-recognition-arduino-ide/

Where to get an ESP32-CAM: https://makeradvisor.com/tools/esp32-cam/

This code is from Arduino ESP32 Repository: https://github.com/espressif/arduino-esp32/tree/master/libraries/ESP32/examples/Camera/CameraWebServer
